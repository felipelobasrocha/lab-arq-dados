# EXEMPLO DE UMA DAG QUE UTILIZA VARIABLES
from airflow import DAG
from airflow.models import Variable
from datetime import datetime
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator

ENV = Variable.get('AMBIENTE')

default_args = {
    'owner': 'aulafia',
    'start_date': datetime(2023, 5, 7)
}
dag = DAG(
    dag_id='dag_exemplo_03',
    default_args=default_args,
    schedule_interval='0 3 * * *'
)

start = DummyOperator(
    task_id='start',
    dag=dag)

task1 = BashOperator(
    task_id='task_1',
    bash_command=f'sleep 10 && echo "{ENV}"',
    dag=dag
)

finish = DummyOperator(
    task_id='finish',
    dag=dag)

start >> task1 >> finish
