import sys
from pyspark.sql import SparkSession

args = sys.argv[1:]

spark = (SparkSession
         .builder
         .getOrCreate())

print('Este é um script pyspark!\n')

print(args)
