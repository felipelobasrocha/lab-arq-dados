import pyspark.sql.functions as fn
from pyspark.sql import SparkSession

spark = (SparkSession.builder
         .config("spark.hadoop.fs.s3a.endpoint", "http://minio:9000")
         .config("spark.hadoop.fs.s3a.access.key", "AqJ2HkXFs2hfWxS4")
         .config("spark.hadoop.fs.s3a.secret.key", "f254hN80Xari9Fuh9HOPVIGyYSiVB8HY")
         .config("spark.hadoop.fs.s3a.path.style.access", True)
         .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
         .config("spark.hadoop.fs.s3a.aws.credentials.provider", "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider")
         .getOrCreate()
        )

df = spark.read.format('csv').option("header", "true").option("sep", ";").load('s3a://raw/tabela.txt')

df.show(12, False)

df_group = (df.repartition(1)
            .groupBy('col1')
            .agg(fn.sum('col3').alias('sum'))
            )

df_group.show(12, False)

(df_group.write
         .format('csv')
         .mode('overwrite')
         .save('s3a://context/tabela_agrupada', sep=';', header=True)
         )