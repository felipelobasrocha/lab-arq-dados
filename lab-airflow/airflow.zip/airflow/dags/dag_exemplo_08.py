import os
from airflow import DAG
from random import randint
from airflow.models import Variable
from datetime import datetime, timedelta
from airflow.operators.dummy_operator import DummyOperator
from operators.daily_task_sensor import DailyExternalTaskSensor
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator

os.environ["JAVA_HOME"] = Variable.get('JAVA_HOME')

default_args = {
    'owner': 'aulafia',
    'start_date': datetime(2023, 5, 9)
}

dag = DAG(dag_id='dag_exemplo_08',
          default_args=default_args,
          schedule_interval='0 3 * * *'
      )

start_dag = DummyOperator(
                task_id='start_dag',
                dag=dag
                )

sensor = DailyExternalTaskSensor(
             task_id = 'sensor',
             external_dag_id = 'dag_exemplo_06',
             external_task_id = 'copy_file',
             retries = 3,
             retry_delay = timedelta(seconds=30),
             dag = dag
             )

task = SparkSubmitOperator(
                          task_id=f'task_id',
                          conn_id='spark_local',
                          jars='/usr/local/airflow/jars/aws-java-sdk-dynamodb-1.11.534.jar,\
                                /usr/local/airflow/jars/aws-java-sdk-core-1.11.534.jar,\
                                /usr/local/airflow/jars/aws-java-sdk-s3-1.11.534.jar,\
                                /usr/local/airflow/jars/hadoop-aws-3.2.2.jar'.replace(' ', ''),
                          conf={'spark.driver.host' : 'localhost',
                                'spark.ui.port' : randint(4040, 5050),
                                'spark.executor.extraJavaOptions': '-Djava.security.egd=file:///dev/urandom -Duser.timezone=UTC',
                                'spark.driver.extraJavaOptions': '-Djava.security.egd=file:///dev/urandom -Duser.timezone=UTC'},
                          driver_memory='500m',
                          num_executors=0,
                          executor_memory='100m',
                          name=f'task_id',
                          application='/usr/local/airflow/dags/spark_scripts/script_pyspark_minio.py',
                          application_args=[],
                          dag=dag
                      )

task_delete = S3DeleteObjectsOperator(
    task_id='delete_raw_file',
    bucket='raw',
    prefix='tabela.txt',
    aws_conn_id='minio_s3',
    dag=dag
)

dag_finish = DummyOperator(
                 task_id='dag_finish',
                 dag=dag
                 )


start_dag >> sensor >> task >> task_delete >> dag_finish