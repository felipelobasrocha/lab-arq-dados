import os
from airflow import DAG
from random import randint
from airflow.models import Variable
from datetime import datetime, timedelta
from airflow.operators.dummy_operator import DummyOperator
from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator

os.environ["JAVA_HOME"] = Variable.get('JAVA_HOME')

PARAMETRO_01 = 'EXEMPLO PARAMETRO 01'
PARAMETRO_02 = 'EXEMPLO PARAMETRO 02'
PARAMETRO_03 = 'EXEMPLO PARAMETRO 03'

default_args = {
    'owner': 'aulafia',
    'start_date': datetime(2023, 5, 9)
}

dag = DAG(dag_id='dag_exemplo_07',
          default_args=default_args,
          schedule_interval='0 3 * * *'
      )

start_dag = DummyOperator(
                task_id='start_dag',
                dag=dag
                )
dag_finish = DummyOperator(
                 task_id='dag_finish',
                 dag=dag
                 )
task = SparkSubmitOperator(
                          task_id=f'task_id',
                          conn_id='spark_local',
                          conf={'spark.driver.host' : 'localhost',
                                'spark.ui.port' : randint(4040, 5050),
                                'spark.executor.extraJavaOptions': '-Djava.security.egd=file:///dev/urandom -Duser.timezone=UTC',
                                'spark.driver.extraJavaOptions': '-Djava.security.egd=file:///dev/urandom -Duser.timezone=UTC'},
                          driver_memory='500m',
                          num_executors=0,
                          executor_memory='100m',
                          name=f'task_id',
                          application='/usr/local/airflow/dags/spark_scripts/script_pyspark.py',
                          application_args=[PARAMETRO_01,
                                            PARAMETRO_02,
                                            PARAMETRO_03],
                          dag=dag
                      )

start_dag >> task >> dag_finish