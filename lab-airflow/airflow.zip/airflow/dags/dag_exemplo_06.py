# EXEMPLO DE UMA DAG QUE UTILIZA TRIGGER RULES
from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.amazon.aws.sensors.s3_key import S3KeySensor
from airflow.providers.amazon.aws.operators.s3_copy_object import S3CopyObjectOperator

default_args = {
    'owner': 'aulafia',
    'start_date': datetime(2023, 5, 7)
}

dag = DAG(
    dag_id='dag_exemplo_06',
    schedule_interval='0 3 * * *',
    default_args=default_args
)

start = DummyOperator(
    task_id='start',
    dag=dag)

task_01 = S3KeySensor(
    task_id='check-tabela.txt',
    bucket_name='landing',
    bucket_key='tabela.txt',
    aws_conn_id='minio_s3',
    execution_timeout=timedelta(seconds=10),
    dag=dag
)

task_02 = S3KeySensor(
    task_id='check-source_file-2.txt',
    bucket_name='landing',
    bucket_key='source_file-2.txt',
    aws_conn_id='minio_s3',
    execution_timeout=timedelta(seconds=10),
    dag=dag
)

task_03 = S3CopyObjectOperator(
    task_id='copy_file',
    source_bucket_name='landing',
    source_bucket_key='tabela.txt',
    dest_bucket_name ='raw',
    dest_bucket_key='tabela.txt',
    aws_conn_id='minio_s3',
    trigger_rule='one_success', ### LISTA COMPLETA DOS TIPOS DE TRIGGER RULES ---> https://airflow.apache.org/docs/apache-airflow/1.10.3/concepts.html?highlight=trigger%20rule
    dag=dag
)

finish = DummyOperator(
    task_id='finish',
    dag=dag)

start >> [task_01 , task_02] >> task_03 >> finish
