# EXEMPLO DE UMA DAG QUE EXECUTA TAREFAS EM SÉRIE
from airflow import DAG
from datetime import datetime
from airflow.operators.bash_operator import BashOperator
from airflow.operators.dummy_operator import DummyOperator

default_args = {
    'owner': 'aulafia',
    'start_date': datetime(2023, 5, 7)
}
dag = DAG(
    dag_id='dag_exemplo_01',
    default_args=default_args,
    schedule_interval='0 3 * * *'
)

start = DummyOperator(
    task_id='start',
    dag=dag)

task1 = BashOperator(
    task_id='task_1',
    bash_command='sleep 10 && echo "Hello World"',
    dag=dag
)
task2 = BashOperator(
    task_id='task_2',
    bash_command='sleep 10 && echo "Hello Airflow" && exit(1)',
    dag=dag
)

finish = DummyOperator(
    task_id='finish',
    dag=dag)

start >> task1 >> task2 >> finish
